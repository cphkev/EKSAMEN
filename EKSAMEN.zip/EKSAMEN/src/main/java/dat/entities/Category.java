package dat.entities;

public enum Category {
    BEACH, CITY, FOREST, LAKE, SEA, SNOW
}
